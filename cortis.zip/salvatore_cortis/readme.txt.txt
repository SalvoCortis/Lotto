Uso questo file .txt per comunicare alcuni cambiamenti che ho apportato al progetto. Mi sono divertito nel provare a creare un server 
user-friendly, ovvero che tenesse conto delle competenze di un comune utente. E' per questo che ho impostato i comandi non proprio come 
illustati nelle specifiche. Inizialmente tra l'altro non avevo effettivamente inteso che bisognassero essere fatti proprio in un 
determinato modo. La logica che c'è dietro è la stessa ovviamente, tuttavia l'esecuzione è leggermente diversa.
Esempio: 
- Nelle specifiche invia_giocata doveva essere !invia_giocata -r <ruote> -n <numeri> -i <importi>
  Nel mio progetto invece invia_giocata è strutturata nel seguente modo: invia_giocata (invio) --> richiede le ruote da inserire 
											       --> richiede i numeri da inserire
											       --> richiede gli importi da inserire

Spero non sia un problema tale libertà che mi sono preso. Avevo anche mandato un'email a riguardo però sto comunque ulteriormente
specificando per evitare sorprese nel momento in cui verrà eseguito il mio progetto. Ciò nonostante il comando 'help' dovrebbe e, mi auguro
che davvero così è, illustrare come eseguire i vari comandi.
Grazie in anticipo per l'attenzione.